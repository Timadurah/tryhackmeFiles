var img = new Image();
img.src = 'https://example.com/image.jpg'; // Replace with a exampl.com with your domain. like https://yourdomain.com/image.jpg
var div = document.createElement('div');
div.innerHTML = img.content;
var scriptUrl = div.firstChild.getAttribute('src');
var script = document.createElement('script');
script.src = scriptUrl;
document.head.appendChild(script);